Assembly 1 - Webots (rebuilt, v4)

Open worlds/Assembly1.wbt in Webots R2025a.

What changed
- The 192 URDF fixed joints are now merged: each rigid cluster of parts is ONE Webots body
  (22 bodies instead of 214). Nothing can "come apart" and the solver is stable.
- 21 HingeJoints remain, each with a RotationalMotor (name = URDF joint name) and a
  PositionSensor (name = <joint>_sensor).
- Real masses from the URDF are used (servos 0.257 kg, etc.); bodies are given a minimum
  mass so mass ratios stay solver-friendly. Density+mass warnings are gone.
- Only the feet collide with the floor.

Controller: controllers/keyboard_control  (click the 3D view first)
  N / P  next / previous joint     UP / DOWN  rotate selected joint
  M      mirror left/right twin    SPACE      zero selected joint
  R      zero all joints           H          help
