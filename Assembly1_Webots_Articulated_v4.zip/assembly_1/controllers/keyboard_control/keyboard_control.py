"""Keyboard control for the Assembly1 robot.

Click inside the 3D view first so Webots receives the key presses.

  N / P        select next / previous joint
  UP / DOWN    rotate the selected joint (hold the key to keep moving)
  M            mirror mode ON/OFF: the left/right twin joint moves with it
  SPACE        send the selected joint back to 0
  R            send ALL joints back to 0
  H            print this help
"""
from controller import Robot, Keyboard

JOINTS = [
    "c_wst_yaw",
    "l_sho_pit", "l_sho_rol", "l_elb_pit",
    "r_sho_pit", "r_sho_rol", "r_elb_pit",
    "l_hip_yaw", "l_hip_rol", "l_hip_pit", "l_kne_pit", "l_ank_pit", "l_ank_rol",
    "r_hip_yaw", "r_hip_rol", "r_hip_pit", "r_kne_pit", "r_ank_pit", "r_ank_rol",
    "revolute_1", "revolute_3",
]
SPEED = 1.5          # rad/s while a key is held
LIMIT = 1.57         # +/- rad software limit

robot = Robot()
dt = int(robot.getBasicTimeStep())
kb = robot.getKeyboard()
kb.enable(dt)

motors, sensors, target = {}, {}, {}
for name in JOINTS:
    m = robot.getDevice(name)
    s = robot.getDevice(name + "_sensor")
    s.enable(dt)
    m.setVelocity(4.0)
    m.setPosition(0.0)
    motors[name], sensors[name], target[name] = m, s, 0.0


def twin(name):
    if name.startswith("l_"):
        return "r_" + name[2:]
    if name.startswith("r_"):
        return "l_" + name[2:]
    return None


sel, mirror = 0, False


def status():
    n = JOINTS[sel]
    print(f"[joint {sel + 1}/{len(JOINTS)}] {n}  target={target[n]:+.2f} rad  mirror={'ON' if mirror else 'off'}")


print(__doc__)
status()
step = SPEED * dt / 1000.0
last = None
while robot.step(dt) != -1:
    keys = set()
    k = kb.getKey()
    while k != -1:
        keys.add(k & 0xFFFF)
        k = kb.getKey()

    changed = False
    for key in keys:
        if key in (ord("N"),) and key != last:
            sel = (sel + 1) % len(JOINTS); changed = True
        elif key == ord("P") and key != last:
            sel = (sel - 1) % len(JOINTS); changed = True
        elif key == ord("M") and key != last:
            mirror = not mirror; changed = True
        elif key == ord("H") and key != last:
            print(__doc__)
        elif key == ord("R") and key != last:
            for n in JOINTS:
                target[n] = 0.0
            changed = True
        elif key == ord(" ") and key != last:
            target[JOINTS[sel]] = 0.0
            changed = True
        elif key in (Keyboard.UP, Keyboard.DOWN):
            d = step if key == Keyboard.UP else -step
            names = [JOINTS[sel]]
            if mirror and twin(JOINTS[sel]) in target:
                names.append(twin(JOINTS[sel]))
            for n in names:
                target[n] = max(-LIMIT, min(LIMIT, target[n] + d))
            changed = True
    last = next(iter(keys)) if len(keys) == 1 else None

    for n in JOINTS:
        motors[n].setPosition(target[n])
    if changed and (keys & {ord("N"), ord("P"), ord("M"), ord("R"), ord(" ")}):
        status()
