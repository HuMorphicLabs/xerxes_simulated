Assembly 1 - Webots (v6, walking controller with balance sensors)

Open worlds/Assembly1.wbt in Webots R2025a, click inside the 3D view, then:

  UP / W      walk forward           LEFT / A   walk turning left
  DOWN / S    walk backward          RIGHT / D  walk turning right
  SPACE       stop and stand         H          help
  B           balance feedback on/off          I   live sensor readout (toggle)

NEW in v6 - sensors and balance
  Sensors (in protos/Assembly1.proto)
    imu, gyro, accelerometer    on the pelvis (axes: x forward, y left, z up)
    lfoot_FL/FR/BL/BR, rfoot_FL/FR/BL/BR   four force pads under each sole (F/B = toe/heel, L/R = foot's left/right)
  Balance (controllers/walk_control/walk_control.py)
    - tilt estimate = gyro + accelerometer complementary filter
    - PD feedback of forward/sideways lean into the ankle joints; the foot pads decide which foot is
      carrying the weight, so the standing foot gets the correction and the swinging foot does not
    - gait slows down when the body tilts, and stops if it falls (> 34 deg)
  Bug fix: the RIGHT foot collision box in v5 was a loose box that sat ~14 deg tilted when the foot was
    flat, so that foot stood on an edge. Both feet now use a flat box built from the real foot mesh.

Tuning (top of walk_control.py)
    KP_PITCH / KD_PITCH, KP_ROLL / KD_ROLL   feedback strength (too high = ankle jitter, too low = still tips)
    PITCH_BIAS / ROLL_BIAS                   if it settles leaning, trim here (radians)
    MAX_CORR, SLOW_TILT, FALL_TILT           limits
    CYCLE_TIME                               larger = slower, safer
  Press I while it runs: the readout shows pitch/roll (deg), the load on each foot (N) and which foot is
  carrying the weight. Standing still, both feet should be roughly equal (~14 N each).

Tools
    tools/add_sensors.py   adds the sensors to the PROTO (already applied; refuses to run twice)
    tools/gen_balance.py   derives the ankle joint signs from the URDF -> controllers/walk_control/balance_params.py
    tools/gen_gait.py      regenerates the gait after changing height/stride/step height   (numpy + scipy)

Controllers
  walk_control      (default) human-like walk + balance
  keyboard_control  manual joint-by-joint control (set Assembly1 { controller "keyboard_control" } in the .wbt)

Known CAD issues the gait works around
- The left/right legs differ in length by about 2.5 cm, so one knee bends more than the other.
- Several joint names are shuffled (e.g. l_ank_pit is really the left HIP pitch). The controller
  maps joints by their position in the kinematic chain, not by name.
- The robot's root link is the left hand; the torso hangs off it. That is why the IMU is on the pelvis.
- Arms can only swing fore/aft (their joint axes are vertical), they cannot hang down.

NEW in v7 - reinforcement learning (PPO)
  worlds/Assembly1_RL.wbt + controllers/rl_walk/rl_walk.py
  The robot is made a Supervisor (protos/Assembly1.proto: new field "supervisor", default FALSE).
  PPO learns small corrections (+-0.12 rad) on top of the v6 gait + balance, so it starts out walking
  and improves. Reward: forward speed, upright, smooth/small actions; -5 for falling.
  1. pip install gymnasium stable-baselines3 torch   (into the Python Webots uses)
  2. open worlds/Assembly1_RL.wbt, set MODE = "train" in rl_walk.py, Run in fast mode (no rendering)
  3. set MODE = "play" to watch the saved model (controllers/rl_walk/models/ppo_walk.zip)
  Not yet tested inside real Webots - first thing to check is that episodes reset (see console).

v7 note: upper body turned 180 deg about the waist (c_wst_yaw) by WAIST_YAW = pi in walk_control.py / rl_walk.py
  (set WAIST_YAW = 0 to disable). Arm joints swapped to match.
