"""Forward / inverse kinematics of the Assembly1 legs, built straight from the URDF."""
import os, sys, math, collections
import numpy as np
from scipy.optimize import least_squares
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
URDF = os.path.join(HERE, '..', 'urdf', 'assembly_1.urdf')

def rpy_to_R(r, p, y):
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]]); Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
    Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
    return Rz @ Ry @ Rx

def axis_rot(a, q):
    a = np.asarray(a, float); a = a / np.linalg.norm(a)
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return np.eye(3) + math.sin(q) * K + (1 - math.cos(q)) * K @ K

def T(xyz, R):
    M = np.eye(4); M[:3, :3] = R; M[:3, 3] = xyz; return M

_t = ET.parse(URDF).getroot()
JOINTS = {}
PARENT_JOINT = {}
for j in _t.findall('joint'):
    d = dict(name=j.get('name'), type=j.get('type'), p=j.find('parent').get('link'), c=j.find('child').get('link'),
             T0=T([float(x) for x in j.find('origin').get('xyz').split()],
                  rpy_to_R(*[float(x) for x in j.find('origin').get('rpy').split()])),
             axis=np.array([float(x) for x in j.find('axis').get('xyz').split()]) if j.find('axis') is not None else None)
    JOINTS[d['name']] = d; PARENT_JOINT[d['c']] = d

def link_world(link, q=None):
    """World pose of a link for hinge angles q (dict name->rad, default 0)."""
    q = q or {}
    chain = []
    l = link
    while l in PARENT_JOINT:
        chain.append(PARENT_JOINT[l]); l = PARENT_JOINT[l]['p']
    M = np.eye(4)
    for j in reversed(chain):
        M = M @ j['T0']
        if j['type'] != 'fixed':
            M = M @ T([0, 0, 0], axis_rot(j['axis'], q.get(j['name'], 0.0)))
    return M

# ---- the legs, listed in the order they appear physically (top -> bottom) ----
# NOTE: the CAD joint *names* of the left-leg pitch joints are shuffled, so roles are assigned by chain order.
LEGS = {
    'L': dict(joints=['l_hip_yaw', 'l_hip_rol', 'l_ank_pit', 'l_kne_pit', 'l_hip_pit', 'l_ank_rol'], foot='feet_mirrored', foot_group_link='support_large_v4_1__body1'),
    'R': dict(joints=['r_hip_yaw', 'r_hip_rol', 'r_hip_pit', 'r_kne_pit', 'r_ank_pit', 'r_ank_rol'], foot='feet', foot_group_link='support_large_v4_1__body1_8'),
}
ROLES = ['hip_yaw', 'hip_roll', 'hip_pitch', 'knee', 'ankle_pitch', 'ankle_roll']
PELVIS_LINK = 'part_1_6'      # child of c_wst_yaw: the pelvis/waist block that carries both hips

W0_PEL = link_world(PELVIS_LINK)
R0_PEL = W0_PEL[:3, :3]

def foot_group_link(leg):
    return JOINTS[LEGS[leg]['joints'][-1]]['c']

# reference vectors in pelvis coordinates (constants of the CAD zero pose)
_u_world = (lambda a: a / np.linalg.norm(a))(R0_PEL @ np.zeros(3) + link_world(JOINTS['l_hip_yaw']['c'])[:3, :3] @ JOINTS['l_hip_yaw']['axis'])
if _u_world[2] < 0: _u_world = -_u_world
U_P = R0_PEL.T @ _u_world                      # pelvis "up"
F_P = R0_PEL.T @ np.array([-1.0, 0, 0])        # forward (robot faces -X in the CAD frame)
F_P = F_P - U_P * (F_P @ U_P); F_P /= np.linalg.norm(F_P)
L_P = np.cross(U_P, F_P)                       # left
B_P = np.stack([F_P, L_P, U_P], axis=1)

def hip_point(leg):
    return (np.linalg.inv(W0_PEL) @ link_world(JOINTS[LEGS[leg]['joints'][0]]['c']))[:3, 3]

HIP_L, HIP_R = hip_point('L'), hip_point('R')
HIP_MID = (HIP_L + HIP_R) / 2

# foot frames
def foot_basis(leg):
    g = foot_group_link(leg)
    Rf = link_world(g)[:3, :3]
    e_f = Rf.T @ np.array([-1.0, 0, 0]); e_u = Rf.T @ np.array([0, 0, 1.0])
    e_l = np.cross(e_u, e_f)
    return np.stack([e_f, e_l, e_u], axis=1)

def foot_ref_offset(leg):
    """Foot-frame point lying under the ankle-pitch axis (so x of Q == x of the ankle axis)."""
    g = foot_group_link(leg)
    Wf = link_world(g)
    ankle_pitch = LEGS[leg]['joints'][4]
    ax_x = link_world(JOINTS[ankle_pitch]['c'])[0, 3]
    s = Wf[0, 3] - ax_x                          # distance along world -X
    e_f = Wf[:3, :3].T @ np.array([-1.0, 0, 0])
    return s * e_f                               # in the foot frame

BF = {k: foot_basis(k) for k in 'LR'}
QOFF = {k: foot_ref_offset(k) for k in 'LR'}
SOLE_BELOW = 0.033                               # origin height above the sole at zero pose (feet are flat on z=0)

def leg_fk(leg, q6):
    """Foot reference point + orientation in pelvis coordinates (axes F,L,U) for 6 leg angles."""
    qd = {n: a for n, a in zip(LEGS[leg]['joints'], q6)}
    Wf = np.linalg.inv(W0_PEL) @ link_world(foot_group_link(leg), qd)
    p = Wf[:3, 3] + Wf[:3, :3] @ QOFF[leg]
    Rfoot = Wf[:3, :3] @ BF[leg]                 # columns: foot fwd, left, up expressed in pelvis frame
    return p, Rfoot

def leg_ik(leg, target_p, yaw, q0):
    """target_p = (fwd, left, up) of the foot reference point relative to the hip midpoint, pelvis axes."""
    p_t = HIP_MID + B_P @ np.asarray(target_p)
    c, s = math.cos(yaw), math.sin(yaw)
    f = c * F_P + s * L_P; l = -s * F_P + c * L_P
    R_t = np.stack([f, l, U_P], axis=1) @ np.eye(3)
    def res(q):
        p, R = leg_fk(leg, q)
        return np.concatenate([(p - p_t) * 20, (R - R_t)[:, :2].ravel() * 3])
    sol = least_squares(res, q0, method='lm', xtol=1e-12, ftol=1e-12)
    return sol.x, float(np.linalg.norm(sol.fun))
