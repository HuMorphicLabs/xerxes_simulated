from kin import *
import re
np.set_printoptions(precision=3,suppress=True)
lo=np.array([-0.8,-1.1,-1.4,0.0,-1.4,-1.0]); hi=np.array([0.8,1.1,1.4,2.0,1.4,1.0])
LAT={k:(B_P.T@((HIP_L if k=='L' else HIP_R)-HIP_MID))[1] for k in 'LR'}
def ik(leg,tp,yaw,q0):
    p_t=HIP_MID+B_P@np.asarray(tp); c,s=math.cos(yaw),math.sin(yaw)
    f=c*F_P+s*L_P; l=-s*F_P+c*L_P; R_t=np.stack([f,l,U_P],axis=1)
    def res(q):
        p,R=leg_fk(leg,q); return np.concatenate([(p-p_t)*20,(R-R_t)[:,:2].ravel()*3])
    s_=least_squares(res,np.clip(q0,lo+1e-6,hi-1e-6),bounds=(lo,hi),xtol=1e-12,ftol=1e-12)
    return s_.x,float(np.linalg.norm(s_.fun))
