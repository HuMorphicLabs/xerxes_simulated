import sys; sys.path.insert(0,'.')
import kin
from neutral import *
import re, struct
t=kin._t
links={l.get('name'):l for l in t.findall('link')}
def vis_of(l):
    out=[]
    for v in links[l].findall('visual'):
        o=v.find('origin'); out.append((T([float(x) for x in o.get('xyz').split()],rpy_to_R(*[float(x) for x in o.get('rpy').split()])),v.find('geometry/mesh').get('filename').split('/')[-1]))
    return out
def mass_of(l):
    m=links[l].find('inertial/mass'); return float(m.get('value')) if m is not None else 0
def stl(path):
    d=open(path,'rb').read()
    if d[:5]==b'solid' and b'facet' in d[:300]:
        return np.array(re.findall(rb'vertex\s+(\S+)\s+(\S+)\s+(\S+)',d),dtype=float)
    n=struct.unpack('<I',d[80:84])[0]
    a=np.frombuffer(d[84:84+50*n],dtype=np.dtype([('n','<3f4'),('v','<9f4'),('a','<u2')]))
    return a['v'].reshape(-1,3).astype(float)
order=['root'];st=['root'];kids=collections.defaultdict(list)
for j in JOINTS.values(): kids[j['p']].append(j)
while st:
    p=st.pop()
    for j in kids[p]: order.append(j['c']); st.append(j['c'])
grp={}
for l in order:
    pj=PARENT_JOINT.get(l)
    grp[l]=l if (pj is None or pj['type']!='fixed') else grp[pj['p']]
members=collections.defaultdict(list)
for l in order: members[grp[l]].append(l)
W0={l:link_world(l) for l in order}
G={}
for g,m in members.items():
    pts=[]
    for l in m:
        for Tv,mesh in vis_of(l):
            M=np.linalg.inv(W0[g])@W0[l]@Tv; P=stl(os.path.join(HERE,'..','meshes',mesh)); pts.append(P@M[:3,:3].T+M[:3,3])
    P=np.vstack(pts) if pts else np.zeros((1,3)); c=(P.min(0)+P.max(0))/2
    G[g]=(max(sum(mass_of(l) for l in m), 0.3 if g=='root' else 0.02),c)
def com(q):
    s=np.zeros(3);M=0
    for g,(m,c) in G.items():
        Wg=link_world(g,q); s+=m*(Wg@np.append(c,1))[:3]; M+=m
    return s/M
def com_pel(q):
    cp=np.linalg.inv(W0_PEL)@np.append(com(q),1); return B_P.T@(cp[:3]-HIP_MID)
