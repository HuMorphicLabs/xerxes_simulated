"""Adds balance sensors to protos/Assembly1.proto (run once:  python3 tools/add_sensors.py).

  * pelvis (c_wst_yaw_body):  InertialUnit "imu", Gyro "gyro", Accelerometer "accelerometer"
        device axes are aligned with the walking frame:  x = forward, y = left, z = up
  * both soles: 4 force pads each  (TouchSensor, force-3d)  lfoot_FL/FR/BL/BR, rfoot_FL/FR/BL/BR
        F/B = front(toe)/back(heel), L/R = the foot's own left/right edge
  * both feet: collision box rebuilt from the real foot mesh, aligned with the foot's sole.
        (v5 had a loose axis-aligned box on the RIGHT foot that is tilted ~14 deg when the foot is
         flat, so that foot stood on an edge.)
"""
import sys, os, re, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from com_check import *

PROTO = os.path.join(HERE, '..', 'protos', 'Assembly1.proto')
PAD, PAD_H = 0.02, 0.006     # pad footprint / height (m)
BOX_RAISE = 0.004            # main foot box sits this far above the sole so the pads carry the load


def axis_angle(R):
    c = max(-1.0, min(1.0, (np.trace(R) - 1) / 2)); a = math.acos(c)
    if a < 1e-9: return (0, 0, 1, 0.0)
    if math.pi - a < 1e-6:
        ax = np.sqrt(np.maximum((np.diag(R) + 1) / 2, 0)); ax[0] = math.copysign(ax[0], R[2, 1] - R[1, 2] or 1)
        ax[1] = math.copysign(ax[1], R[0, 2] - R[2, 0] or 1); ax[2] = math.copysign(ax[2], R[1, 0] - R[0, 1] or 1)
        ax /= np.linalg.norm(ax); return (*ax, a)
    ax = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]]) / (2 * math.sin(a))
    return (*(ax / np.linalg.norm(ax)), a)

def rot_txt(R): return 'rotation %.6f %.6f %.6f %.6f' % axis_angle(R)
def vec(v): return '%.5f %.5f %.5f' % tuple(v)

text = open(PROTO).read()
if 'name "imu"' in text:
    sys.exit('already has sensors - nothing to do')

# ------------------------------------------------------------------ 1. IMU on the pelvis
i = text.index('name "c_wst_yaw_body"'); j = text.index('children [', i) + len('children [')
imu = ('\n  InertialUnit { %s name "imu" }\n  Gyro { %s name "gyro" }\n  Accelerometer { %s name "accelerometer" }' %
       (rot_txt(B_P), rot_txt(B_P), rot_txt(B_P)))
text = text[:j] + imu + text[j:]

# ------------------------------------------------------------------ 2. feet
MESH = {'L': 'Feet_Mirrored', 'R': 'Feet'}
BODY = {'L': 'l_ank_rol_body', 'R': 'r_ank_rol_body'}
PREFIX = {'L': 'lfoot', 'R': 'rfoot'}
for leg in 'LR':
    # foot mesh pose inside the foot Solid, read from the PROTO itself
    m = re.search(r'Transform \{ translation (\S+) (\S+) (\S+) rotation (\S+) (\S+) (\S+) (\S+) children \[ Shape \{[^\n]*?meshes/%s\.stl' % MESH[leg], text)
    tr = np.array([float(m.group(k)) for k in (1, 2, 3)]); ax = [float(m.group(k)) for k in (4, 5, 6)]; an = float(m.group(7))
    P = stl(os.path.join(HERE, '..', 'meshes', MESH[leg] + '.stl')) @ axis_rot(ax, an).T + tr
    B = BF[leg]                                  # columns: foot fwd, left, up (in the foot Solid frame)
    Q = P @ B; mn, mx = Q.min(0), Q.max(0)       # extents along fwd / left / up
    mn = np.round(mn, 4); mx = np.round(mx, 4)
    print(leg, 'foot extents fwd', mn[0], mx[0], ' left', mn[1], mx[1], ' up', mn[2], mx[2])

    # main collision box (aligned with the sole, floating BOX_RAISE above it)
    lo = mn.copy(); lo[2] += BOX_RAISE
    box_c = (lo + mx) / 2; box_s = mx - lo
    bo = ('boundingObject Transform { translation %s %s children [ Box { size %s } ] }' %
          (vec(B @ box_c), rot_txt(B), vec(box_s)))
    # force pads at the four corners of the sole
    pads = []
    for fn, f in (('F', mx[0] - PAD / 2), ('B', mn[0] + PAD / 2)):
        for ln, l in (('L', mx[1] - PAD / 2), ('R', mn[1] + PAD / 2)):
            c = np.array([f, l, mn[2] + PAD_H / 2])
            pads.append('  TouchSensor { translation %s %s name "%s_%s%s" type "force-3d" '
                        'boundingObject Box { size %s } physics Physics { density -1 mass 0.002 } }' %
                        (vec(B @ c), rot_txt(B), PREFIX[leg], fn, ln, vec([PAD, PAD, PAD_H])))
    k = text.index('name "%s"' % BODY[leg])
    b0 = text.index('boundingObject Transform', k); b1 = text.index('\n', b0)
    text = text[:b0] + bo + text[b1:]
    close = text.rfind('\n', 0, text.rfind('\n', 0, b0))        # start of the line holding the "]" that closes children
    text = text[:close] + '\n' + '\n'.join(pads) + text[close:]

# sanity: brackets balanced
assert text.count('{') == text.count('}') and text.count('[') == text.count(']'), 'unbalanced brackets'
open(PROTO, 'w').write(text)
print('sensors added to', os.path.normpath(PROTO))
