"""Human-like walking controller for Assembly1 - v6: closed-loop balance using sensors.

Click inside the 3D view first so Webots receives the key presses.

  UP    / W   walk forward           LEFT  / A   walk turning left
  DOWN  / S   walk backward          RIGHT / D   walk turning right
  SPACE       stop and stand         H           print this help
  B           balance feedback on/off          I   print sensor readout (toggle)

Sensors (all on the robot, see protos/Assembly1.proto):
  imu / gyro / accelerometer   on the pelvis, axes = x forward, y left, z up
  lfoot_FL FR BL BR, rfoot_FL FR BL BR   four force pads under each sole

How it works
  1. gait_tables.py holds a walking cycle computed offline by inverse kinematics (tools/gen_gait.py).
  2. Body tilt (pitch / roll) is estimated by fusing the gyro with the accelerometer (complementary filter).
  3. The tilt is fed back to the ANKLES (PD law): lean forward -> toes press down, lean sideways -> ankle roll.
     The foot force pads tell which foot is carrying the weight, so the standing foot gets the correction
     and the foot in the air is left alone.
  4. If the gait is tilting too much it slows down; if the body tips past FALL_TILT it stops and stands.
"""
import math
from controller import Robot, Keyboard
from gait_tables import JOINT_NAMES, STAND, N, TABLES
from balance_params import ANKLE_MAP

# ------------------------------------------------------------------ tuning
CYCLE_TIME   = 1.6    # seconds for one full stride (2 steps). Larger = slower, safer.
STARTUP_TIME = 3.0    # seconds to move from the CAD pose into the standing pose
BLEND_TIME   = 1.2    # seconds to fade in / out of walking
ARM_SWING    = 0.35   # rad, arm swing amplitude (0 = arms still)
MOTOR_SPEED  = 4.0    # rad/s limit sent to the motors

# --- balance feedback (set BALANCE_ON = False to get the old open-loop walk) ---
BALANCE_ON   = True
KP_PITCH     = 1.0    # rad of ankle correction per rad of forward/backward lean
KD_PITCH     = 0.10   # ... per rad/s of pitch rate
KP_ROLL      = 1.0    # rad of ankle correction per rad of sideways lean
KD_ROLL      = 0.10   # ... per rad/s of roll rate
MAX_CORR     = 0.25   # rad, largest ankle correction
PITCH_BIAS   = 0.0    # rad, trim if the robot settles leaning (+ = forward)
ROLL_BIAS    = 0.0    # rad, trim for sideways lean (+ = left side up)
SLOW_TILT    = 0.12   # rad, above this tilt the gait slows down
FALL_TILT    = 0.60   # rad (~34 deg), beyond this the robot gives up and stands
ACC_TAU      = 0.6    # s, how fast the accelerometer corrects the gyro estimate
CONTACT_MIN  = 2.0    # N, minimum total sole force to trust the load sharing between feet
GRAVITY      = 9.81

# arms: with this CAD the shoulder-"roll" joints (vertical axes) swing the arms fore/aft.
# r_sho_rol drives the robot's LEFT arm (+ = forward); l_sho_rol drives the RIGHT arm (+ = backward).
WAIST_YAW = math.pi   # rad: turns the upper body (above the waist) 180 deg to face the walking direction. 0 = leave as CAD.
# (after the 180 deg waist turn the two arms swap sides, so the arm joints are swapped too)
LEFT_ARM, RIGHT_ARM = "l_sho_rol", "r_sho_rol"
HOLD_AT_ZERO = ["c_wst_yaw", "revolute_1", "revolute_3", "l_sho_pit", "r_sho_pit", "l_elb_pit", "r_elb_pit"]
# ------------------------------------------------------------------

robot = Robot()
dt = int(robot.getBasicTimeStep())
dts = dt / 1000.0
kb = robot.getKeyboard()
kb.enable(dt)

ALL = list(JOINT_NAMES) + [LEFT_ARM, RIGHT_ARM] + HOLD_AT_ZERO
motors = {}
for n in ALL:
    m = robot.getDevice(n)
    m.setVelocity(MOTOR_SPEED)
    m.setPosition(0.0)
    motors[n] = m
    robot.getDevice(n + "_sensor").enable(dt)

# ---- balance sensors (if one is missing the robot still walks, just without balance feedback) ----
missing = []


def get_sensor(name):
    d = robot.getDevice(name)
    if d is None:
        missing.append(name)
        return None
    d.enable(dt)
    return d


imu = get_sensor("imu")
gyro = get_sensor("gyro")
accel = get_sensor("accelerometer")
PADS = {}
for foot in ("lfoot", "rfoot"):
    PADS[foot] = [get_sensor("%s_%s" % (foot, c)) for c in ("FL", "FR", "BL", "BR")]
SENSORS_OK = not missing
if missing:
    print("WARNING: sensors not found in the robot:", missing)
    print("         -> walking WITHOUT balance feedback. Make sure protos/Assembly1.proto is the v6 one and reload the world.")


def foot_load(foot):
    """Total force (N) on one sole = sum of its four pads."""
    s = 0.0
    for p in PADS[foot]:
        v = p.getValues()[:3]          # force-3d: use the first three numbers (fx, fy, fz)
        s += math.sqrt(sum(x * x for x in v))
    return s


def smooth(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def clamp(x, lim):
    return max(-lim, min(lim, x))


def sample(table, phase):
    """Linear interpolation of the cyclic table at phase in [0,1)."""
    f = (phase % 1.0) * N
    i = int(f) % N
    j = (i + 1) % N
    a = f - int(f)
    r0, r1 = table[i], table[j]
    return [r0[k] + (r1[k] - r0[k]) * a for k in range(len(r0))]


MODES = {"stand": None, "forward": ("fwd", +1), "backward": ("fwd", -1),
         "left": ("turn_left", +1), "right": ("turn_right", +1)}
KEYMAP = {Keyboard.UP: "forward", ord("W"): "forward", Keyboard.DOWN: "backward", ord("S"): "backward",
          Keyboard.LEFT: "left", ord("A"): "left", Keyboard.RIGHT: "right", ord("D"): "right",
          ord(" "): "stand"}

print(__doc__)
mode, active, wanted, alpha, phase, t = "stand", ("fwd", +1), ("fwd", +1), 0.0, 0.0, 0.0
last_key = -1

# ---- state of the tilt estimator: "up" = world-up direction written in pelvis axes (forward, left, up) ----
up = [-0.004, -0.215, 0.977]       # CAD start pose (pelvis is tilted ~12 deg sideways there); the filter corrects it
acc_sign, acc_sum, acc_checked = 1.0, 0.0, False
pitch = roll = 0.0                 # + pitch = leaning forward, + roll = left side up (radians)
rate_p = rate_r = 0.0              # low-passed angular rates about the left / forward axes
share = {"lfoot": 0.5, "rfoot": 0.5}
balance_on, fallen, debug, next_debug = BALANCE_ON and SENSORS_OK, False, False, 0.0

while robot.step(dt) != -1:
    t += dts

    # ================= sensing =================
    if SENSORS_OK:
        wF, wL, wU = gyro.getValues()[:3]         # rad/s about forward / left / up
        a = accel.getValues()[:3]                 # m/s^2, reads +g along "up" at rest
    else:
        wF = wL = wU = 0.0
        a = [0.0, 0.0, 0.0]

    # integrate the gyro:  d(up)/dt = -(w x up)
    ux, uy, uz = up
    up = [ux - (wL * uz - wU * uy) * dts,
          uy - (wU * ux - wF * uz) * dts,
          uz - (wF * uy - wL * ux) * dts]

    # one-off check of the accelerometer sign while standing up (the pelvis cannot be upside down)
    if 1.0 < t < 2.8:
        acc_sum += a[2]
    elif t >= 2.8 and not acc_checked:
        acc_checked = True
        acc_sign = 1.0 if acc_sum >= 0 else -1.0
        print("accelerometer check: sign %+d" % acc_sign)

    # accelerometer slowly pulls the estimate toward gravity (ignored while the body is accelerating hard)
    an = math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])
    if SENSORS_OK and t > 0.5 and abs(an - GRAVITY) < 1.5:
        k = min(1.0, dts / ACC_TAU)
        up = [up[i] + k * (acc_sign * a[i] / an - up[i]) for i in range(3)]
    nrm = math.sqrt(up[0] ** 2 + up[1] ** 2 + up[2] ** 2)
    up = [v / nrm for v in up]

    pitch = math.atan2(-up[0], up[2])             # + = leaning forward
    roll = math.atan2(up[1], up[2])               # + = left side up
    lp = min(1.0, dts / 0.03)
    rate_p += lp * (wL - rate_p)
    rate_r += lp * (wF - rate_r)
    tilt = math.acos(max(-1.0, min(1.0, up[2])))

    # which foot carries the weight?
    loads = {f: foot_load(f) for f in PADS} if SENSORS_OK else {"lfoot": 0.0, "rfoot": 0.0}
    total = loads["lfoot"] + loads["rfoot"]
    for f in PADS:
        raw = loads[f] / total if total > CONTACT_MIN else 0.5
        share[f] += min(1.0, dts / 0.05) * (raw - share[f])

    # ================= keyboard =================
    k = kb.getKey()
    newest = -1
    while k != -1:
        newest = k & 0xFFFF
        k = kb.getKey()
    if newest != -1 and newest != last_key:
        if newest == ord("H"):
            print(__doc__)
        elif newest == ord("B"):
            balance_on = not balance_on
            print("balance feedback:", "ON" if balance_on else "OFF")
        elif newest == ord("I"):
            debug = not debug
            print("sensor readout:", "ON" if debug else "OFF")
        elif newest in KEYMAP:
            if fallen:
                print("robot has fallen - restart the simulation")
            else:
                mode = KEYMAP[newest]
                if MODES[mode]:
                    wanted = MODES[mode]
                print("mode:", mode)
    last_key = newest

    # ================= fall detection =================
    if SENSORS_OK and not fallen and t > STARTUP_TIME + 1.0 and tilt > FALL_TILT:
        fallen, mode = True, "stand"
        print("FALLEN (tilt %.0f deg) - stopped. Restart the simulation (Ctrl+Shift+R)." % math.degrees(tilt))

    # ---- stand-up ramp (CAD pose -> upright stance) ----
    stand_up = smooth(t / STARTUP_TIME)
    walking_allowed = t > STARTUP_TIME

    # ---- walk blend: a different gait (direction / turn) is only started after fading back to standing ----
    want_walk = bool(MODES[mode]) and walking_allowed
    if want_walk and alpha == 0.0 and active != wanted:
        active, phase = wanted, 0.0
    target_alpha = 1.0 if (want_walk and active == wanted) else 0.0
    step = dts / BLEND_TIME
    alpha = min(target_alpha, alpha + step) if alpha < target_alpha else max(target_alpha, alpha - step)

    # ---- the gait slows down when the body tilts too much ----
    slow = 1.0
    if balance_on and not fallen:
        slow = 1.0 - min(0.7, max(0.0, (tilt - SLOW_TILT) / 0.2))
    if alpha > 0.0:
        phase = (phase + active[1] * dts / CYCLE_TIME * slow) % 1.0

    row = sample(TABLES[active[0]], phase)
    legs = [STAND[i] + alpha * (row[i] - STAND[i]) for i in range(12)]
    x_left, x_right = row[12], row[13]            # normalised fore/aft foot position, +1 = fully forward

    cmd = {}
    for i, n in enumerate(JOINT_NAMES):
        cmd[n] = legs[i] * stand_up
    cmd[LEFT_ARM] = -ARM_SWING * alpha * x_left
    cmd[RIGHT_ARM] = +ARM_SWING * alpha * x_right
    for n in HOLD_AT_ZERO:
        cmd[n] = 0.0
    cmd["c_wst_yaw"] = WAIST_YAW * stand_up

    # ================= balance feedback (ankle strategy) =================
    if balance_on and not fallen:
        gain = smooth((t - (STARTUP_TIME - 0.5)) / 1.0)       # fades in as the robot finishes standing up
        # desired change of the FOOT angle relative to the pelvis: lean forward -> +pitch, left side up -> +roll
        d_pitch = clamp(KP_PITCH * (pitch - PITCH_BIAS) + KD_PITCH * rate_p, MAX_CORR)
        d_roll = clamp(KP_ROLL * (roll - ROLL_BIAS) + KD_ROLL * rate_r, MAX_CORR)
        for leg, foot in (("L", "lfoot"), ("R", "rfoot")):
            w = 2.0 * share[foot] * gain                      # 0 = foot in the air ... 2 = carries everything
            pj, rj, M = ANKLE_MAP[leg]
            cmd[pj] += M[0][0] * w * d_pitch + M[0][1] * w * d_roll
            cmd[rj] += M[1][0] * w * d_pitch + M[1][1] * w * d_roll

    for n, v in cmd.items():
        motors[n].setPosition(v)

    # ================= readout =================
    if debug and t >= next_debug:
        next_debug = t + 0.5
        r, p, y = imu.getRollPitchYaw() if SENSORS_OK else (0, 0, 0)
        print("t=%5.1f pitch %+5.1f roll %+5.1f deg | imu r/p %+5.1f/%+5.1f | load L %4.1f R %4.1f N | share L %.2f | slow %.2f" %
              (t, math.degrees(pitch), math.degrees(roll), math.degrees(r), math.degrees(p),
               loads["lfoot"], loads["rfoot"], share["lfoot"], slow))
